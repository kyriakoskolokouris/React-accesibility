import React from 'react'
// import css from './home.css'

const Contact = () => {
  return(
    <>
    contact
    </>
  )
}

export default Contact