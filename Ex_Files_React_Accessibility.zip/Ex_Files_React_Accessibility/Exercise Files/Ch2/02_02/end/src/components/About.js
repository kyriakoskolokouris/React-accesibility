import React from 'react'
// import css from './home.css'

const About = () => {
  return(
    <>
    about
    </>
  )
}

export default About