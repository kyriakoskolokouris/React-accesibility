import React from 'react'
// import css from './home.css'

const Shop = () => {
  return(
    <>
    Shop
    </>
  )
}

export default Shop