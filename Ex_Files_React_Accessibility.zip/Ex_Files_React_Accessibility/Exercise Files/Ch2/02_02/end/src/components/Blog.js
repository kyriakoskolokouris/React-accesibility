import React from 'react'
// import css from './home.css'

const Blog = () => {
  return(
    <>
    blog
    </>
  )
}

export default Blog